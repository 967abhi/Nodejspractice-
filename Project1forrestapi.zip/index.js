const express=require('express')
const user = require("./MOCK_DATA.json");
const fs=require('fs');

const app=express();
const PORT=8000;
//plugin , Middleware 
app.use(express.urlencoded({extended:false}))
//Routes 
app.get('/api/user',(req,res)=>{
    return res.json(user);
})
app.get("/user",(req,res)=>{
    //<ul><li>username </li></ul>
    const html= `
    <ul>
      ${user.map(user => `<li>${user.first_name}</li>`).join('')}
    </ul>
  `;
    res.send(html);
});
app.get("/api/user/:id",(req,res)=>{
    const id=Number(req.params.id);
    const users=user.find((user)=>user.id===id)
    return res.json(users);
})

//to create new user 
app.post("/api/user",(req,res)=>{
    const body= req.body;
   user.push({...body, id: user.length + 1});
   fs.writeFile('./MOCK_DATA.json',JSON.stringify(user),(err,data)=>{

       return res.json({status:"sucess" , id:user.length + 1})
   });
});

app.listen(PORT,()=> console.log(`Server Started at port :${PORT}`))